import React, { useState, useEffect, useRef, useCallback } from "react";
import { faqData } from "@/data/faqData";
import { FaStar } from "react-icons/fa";
import FaqItem from "@/components/common/FaqItem";
import FilterDropdown from "@/components/common/FilterDropdown";
import EmptyBookmarkList from "./EmptyBookmarkList";

const getBookmarkedIds = () => {
  try {
    return JSON.parse(localStorage.getItem("questionBookmarks")) || [];
  } catch {
    return [];
  }
};

const PAGE_SIZE = 3;

// 북마크 데이터 변환 (title, desc → job, type, question)
const convertToBookmarkData = (item) => {
  return {
    ...item,
    job: item.career || "",
    type: item.type || "",
    question: item.question || "",
    answer: item.answer || "",
    recommendation: item.recommendation || "",
  };
};

const QuestionBookmarkList = ({ testEmpty }) => {
  const [openIds, setOpenIds] = useState([]);
  const [job, setJob] = useState("직군·직무");
  const [questionType, setQuestionType] = useState("질문유형");
  const [starredItems, setStarredItems] = useState(getBookmarkedIds());
  
  // 무한 스크롤 관련 상태 추가
  const [page, setPage] = useState(0);
  const [visibleResults, setVisibleResults] = useState([]);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [userScrolled, setUserScrolled] = useState(false);
  const observer = useRef();

  const toggleBookmark = (id) => {
    const updated = starredItems.includes(id)
      ? starredItems.filter((bid) => bid !== id)
      : [...starredItems, id];
    setStarredItems(updated);
    localStorage.setItem("questionBookmarks", JSON.stringify(updated));
  };

  const toggleOpen = (id) => {
    setOpenIds((prev) =>
      prev.includes(id)
        ? prev.filter((openId) => openId !== id)
        : [...prev, id],
    );
  };

  // 직무 필터 옵션
  const jobOptions = [
    { value: "직군·직무", label: "직군·직무" },
    { value: "프론트엔드 개발자", label: "프론트엔드 개발자" },
    { value: "백엔드 개발자", label: "백엔드 개발자" },
    { value: "모바일 개발자", label: "모바일 개발자" }
  ];
  
  // 질문유형 필터 옵션
  const typeOptions = [
    { value: "질문유형", label: "질문유형" },
    { value: "인성", label: "인성" },
    { value: "직무", label: "직무" },
    { value: "프로젝트", label: "프로젝트" }
  ];

  // 간단한 직무 필터 변경 핸들러
  const handleJobFilterChange = (value) => {
    // 상태 업데이트
    setJob(value);
    
    // 필터 변경 후 바로 데이터 필터링 및 UI 업데이트
    const filteredData = getFilteredBookmarksByFilters(value, questionType);
    setVisibleResults(filteredData.slice(0, PAGE_SIZE));
    setPage(0);
    setHasMore(filteredData.length > PAGE_SIZE);
    setUserScrolled(false);
  };

  // 간단한 질문유형 필터 변경 핸들러
  const handleTypeFilterChange = (value) => {
    // 상태 업데이트
    setQuestionType(value);
    
    // 필터 변경 후 바로 데이터 필터링 및 UI 업데이트
    const filteredData = getFilteredBookmarksByFilters(job, value);
    setVisibleResults(filteredData.slice(0, PAGE_SIZE));
    setPage(0);
    setHasMore(filteredData.length > PAGE_SIZE);
    setUserScrolled(false);
  };
  
  // 특정 필터로 데이터 필터링 (핸들러에서 사용)
  const getFilteredBookmarksByFilters = (jobFilter, typeFilter) => {
    return testEmpty
      ? []
      : faqData
          .filter((item) => {
            // 1. 직무(job) 필터링
            const careerMatch = jobFilter === "직군·직무" || item.job === jobFilter || item.career === jobFilter;
            // 2. 질문유형 필터링
            const typeMatch =
              typeFilter === "질문유형" || item.type === typeFilter;
            // 3. 기존 type '일반' 제외 필터링
            const notGeneral = item.type !== "일반";
            return careerMatch && typeMatch && notGeneral;
          })
          .map((item) => ({
            ...convertToBookmarkData(item),
            isBookmarked: starredItems.includes(item.id),
          }));
  };

  // 북마크 여부 포함하여 전체 데이터 변환 및 필터링 (useEffect에서 사용)
  const getFilteredBookmarks = () => {
    return getFilteredBookmarksByFilters(job, questionType);
  };

  // 마지막 요소 참조 콜백 함수
  const lastResultElementRef = useCallback(
    (node) => {
      // 사용자가 스크롤하지 않았거나 로딩 중이면 관찰하지 않음
      if (loading || !userScrolled) return;

      if (observer.current) observer.current.disconnect();

      observer.current = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting && hasMore && userScrolled) {
            loadMoreResults();
          }
        },
        {
          root: null,
          rootMargin: "0px 0px 50px 0px",
          threshold: 0.5,
        },
      );

      if (node) observer.current.observe(node);
    },
    [loading, hasMore, userScrolled],
  );

  // 스크롤 이벤트 처리
  useEffect(() => {
    // 초기 스크롤 위치 저장
    let prevScrollY = window.scrollY;
    let scrolledDown = false;
    let scrollTimeout;

    const handleScroll = () => {
      // 사용자 스크롤 상태를 true로 설정
      if (!userScrolled) {
        setUserScrolled(true);
      }

      // 스크롤 디바운싱 (스크롤 이벤트가 너무 자주 발생하는 것 방지)
      clearTimeout(scrollTimeout);

      scrollTimeout = setTimeout(() => {
        // 사용자가 아래로 스크롤 했는지 확인
        const currentScrollY = window.scrollY;
        scrolledDown = currentScrollY > prevScrollY;
        prevScrollY = currentScrollY;

        // 아래로 스크롤했을 때만 로드하고, 충분히 아래로 내려갔을 때만 트리거
        if (
          scrolledDown &&
          window.innerHeight + window.scrollY >=
            document.body.offsetHeight - 200 &&
          !loading &&
          hasMore
        ) {
          loadMoreResults();
        }
      }, 100); // 디바운싱 시간
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      clearTimeout(scrollTimeout);
    };
  }, [loading, hasMore, userScrolled]);

  // 추가 결과 로드 함수
  const loadMoreResults = () => {
    if (!hasMore || loading) return;

    setLoading(true);

    // 실제 API 호출 대신 지연 시간 추가 (시뮬레이션)
    setTimeout(() => {
      const filteredBookmarks = getFilteredBookmarks();
      const nextPageResults = filteredBookmarks.slice(
        (page + 1) * PAGE_SIZE,
        (page + 2) * PAGE_SIZE,
      );

      if (nextPageResults.length === 0) {
        setHasMore(false);
      } else {
        setVisibleResults((prev) => [...prev, ...nextPageResults]);
        setPage((prevPage) => prevPage + 1);
      }

      setLoading(false);
    }, 600); // 로딩 시간 증가
  };

  // 즐겨찾기 변경 시 데이터 업데이트
  useEffect(() => {
    const filteredBookmarks = getFilteredBookmarks();
    setVisibleResults(filteredBookmarks.slice(0, PAGE_SIZE));
    setPage(0);
    setHasMore(filteredBookmarks.length > PAGE_SIZE);
    setUserScrolled(false);
  }, [starredItems]); // 즐겨찾기 의존성만 유지

  // 초기 데이터 로드
  useEffect(() => {
    const filteredBookmarks = getFilteredBookmarks();
    setVisibleResults(filteredBookmarks.slice(0, PAGE_SIZE));
    setPage(0);
    setHasMore(filteredBookmarks.length > PAGE_SIZE);
    setUserScrolled(false); // 초기 로드 시 스크롤 상태 초기화
  }, [testEmpty]);

  return (
    <div className="mx-auto w-full pt-6">
      <h2 className="text-zik-text mb-6 text-center text-2xl font-bold sm:text-3xl">
        질문 북마크
      </h2>
      {/* 필터 영역 */}
      <div className="mb-4 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1">
          {/* 직무 드롭다운 - 재사용 컴포넌트 적용 */}
          <FilterDropdown
            value={job}
            onChange={handleJobFilterChange}
            options={jobOptions}
            className="mr-2"
          />
          
          {/* 질문유형 드롭다운 - 재사용 컴포넌트 적용 */}
          <FilterDropdown
            value={questionType}
            onChange={handleTypeFilterChange}
            options={typeOptions}
          />
        </div>
      </div>
      
      {/* 북마크 아이템이 없을 때 빈 상태 표시 */}
      {visibleResults.length === 0 ? (
        <EmptyBookmarkList 
          job={job}
          setJob={handleJobFilterChange}
          type={questionType}
          setType={handleTypeFilterChange}
          isCareerModalOpen={false}
          setCareerModalOpen={() => {}}
        />
      ) : (
        <>
          {/* 표 헤더 */}
          <div className="mb-3 hidden grid-cols-12 items-center border-t-2 border-b-2 border-t-gray-500 border-b-gray-200 px-1 py-2 text-xs font-semibold tracking-wide text-gray-400 sm:grid sm:px-2 sm:text-sm md:px-4 md:text-base">
            <div className="pr-4 text-center sm:pr-6 md:pr-14">No</div>
            <div className="col-span-0 pr-4 text-center sm:pr-6 md:pr-13">직무</div>
            <div className="col-span-1 pl-4 text-center sm:pl-6 md:pl-12">유형</div>
            <div className="col-span-8 pl-4 text-left sm:pl-6 md:pl-25">질문</div>
            <div className="col-span-1 flex justify-center">즐겨찾기</div>
          </div>
          
          {/* 스크롤 영역 컨테이너 */}
          <div className="h-[500px] overflow-y-auto border border-gray-100 rounded-lg mb-4 pr-2">
            {/* 데이터 - FaqItem 컴포넌트 활용 */}
            {visibleResults.map((item, idx) => (
              <div
                key={item.id}
                className="mb-3"
                ref={idx === visibleResults.length - 1 ? lastResultElementRef : null}
              >
                <FaqItem
                  id={`${page * PAGE_SIZE + idx + 1}`}
                  career={item.job}
                  type={item.type}
                  question={item.question}
                  answer={item.answer}
                  recommendation={item.recommendation}
                  isExpanded={openIds.includes(item.id)}
                  onToggle={() => toggleOpen(item.id)}
                  isStarred={item.isBookmarked}
                  onStarToggle={() => toggleBookmark(item.id)}
                  textColors={{
                    normal: "text-gray-700",
                    accent: "text-zik-main"
                  }}
                />
              </div>
            ))}
            
            {/* 로딩 인디케이터 */}
            {loading && (
              <div className="my-6 flex justify-center">
                <div className="h-10 w-10 animate-spin rounded-full border-t-2 border-b-2 border-indigo-500"></div>
              </div>
            )}
            
            {/* 스크롤 시 보여줄 "더 많은 콘텐츠 불러오는 중" 메시지 */}
            {hasMore && !loading && visibleResults.length > 0 && (
              <div className="my-4 text-center text-sm text-gray-400 bg-gray-50 py-2 rounded-lg">
                스크롤하여 더 많은 북마크를 확인하세요 ▼
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default QuestionBookmarkList;
