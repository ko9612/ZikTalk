import React from "react";
import NotFoundPage from "@/components/common/NotFoundPage";

const Test = () => {
  return <NotFoundPage />;
};

export default Test;
