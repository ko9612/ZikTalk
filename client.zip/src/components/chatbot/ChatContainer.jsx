// 임시

const ChatContainer = () => {
  return (
    <section className="z-30 flex h-[620px] w-[800px] justify-center rounded-3xl border bg-white shadow-lg sm:ml-0 sm:w-[480px]">
      container
    </section>
  );
};

export default ChatContainer;
